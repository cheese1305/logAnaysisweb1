package com.Y.android;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Spinnerr extends Activity implements OnClickListener{
	private Spinner spinner;
	private List<String> data_list;
	private ArrayAdapter<String> arr_adapter;
	
	private WebView chartshow_wb;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.spinnerr);
        initView();
	}
	/**
	 * ��ʼ��ҳ��Ԫ��
	 */
	private void initView(){
        spinner=(Spinner)findViewById(R.id.spinner);
		
		data_list=new ArrayList<String>();
		data_list.add("2016_08_20");
		data_list.add("2016_08_21");
		data_list.add("2016_08_22");
		data_list.add("2016_08_23");
		data_list.add("2016_08_24");
		data_list.add("2016_08_25");
		data_list.add("2016_08_26");
		
		//������
        arr_adapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, data_list);
      //������ʽ
        arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //����������
        spinner.setAdapter(arr_adapter);
		
        chartshow_wb=(WebView)findViewById(R.id.chartshow_wb);
		//����webwiev��һ������
		//���������ļ���ȡ��Ĭ��Ϊtrue��������Ҳ���ԣ�
		chartshow_wb.getSettings().setAllowFileAccess(true);
		//�����ű�֧��
		chartshow_wb.getSettings().setJavaScriptEnabled(true);
		chartshow_wb.loadUrl("file:///android_asset/echart/myechart.html");
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.spinner:
			Intent intent1=new Intent(Spinnerr.this,MainActivity.class);
			startActivity(intent1);
			break;
			default:
			break;
		}
		
	}
		
}

