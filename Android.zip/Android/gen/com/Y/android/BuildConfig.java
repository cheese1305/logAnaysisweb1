/** Automatically generated file. DO NOT MODIFY */
package com.Y.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}